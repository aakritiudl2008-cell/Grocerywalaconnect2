const shops=[
{name:"Hill Fresh Mart",area:"Siliguri",distance:"0.8 km",rating:"4.8",items:["Rice","Milk","Vegetables"],phone:"9876543210"},
{name:"Pahadi Grocery Hub",area:"Darjeeling",distance:"1.2 km",rating:"4.7",items:["Tea","Flour","Snacks"],phone:"9876543211"},
{name:"Daily Needs Corner",area:"Kurseong",distance:"0.6 km",rating:"4.6",items:["Milk","Bread","Eggs"],phone:"9876543212"},
{name:"Green Basket Store",area:"Siliguri",distance:"1.5 km",rating:"4.5",items:["Fruits","Vegetables","Oil"],phone:"9876543213"},
{name:"Mountain Mini Mart",area:"Darjeeling",distance:"0.9 km",rating:"4.9",items:["Rice","Tea","Biscuits"],phone:"9876543214"},
{name:"Neighbourhood Kirana",area:"Siliguri",distance:"2.0 km",rating:"4.4",items:["Spices","Dal","Soap"],phone:"9876543215"}
];

const grid=document.getElementById("shopGrid");
const status=document.getElementById("status");
const count=document.getElementById("shopCount");

function render(list=shops){
 grid.innerHTML=list.map((s,i)=>`<article class="card">
 <div class="shop-icon">🛍️</div>
 <h3>${s.name}</h3>
 <div class="muted">📍 ${s.area} • ${s.distance} away</div>
 <div class="muted">⭐ ${s.rating} • Open now</div>
 <div class="chips">${s.items.map(x=>`<span class="chip">${x}</span>`).join("")}</div>
 <button onclick="viewShop(${i})">View shop & directions</button>
 </article>`).join("");
 count.textContent=list.length;
}
function viewShop(i){
 const s=shops[i%shops.length];
 status.textContent=`Selected: ${s.name} — ${s.phone}. Demo directions can be connected to Maps in the next version.`;
 window.scrollTo({top:0,behavior:"smooth"});
}
function filter(){
 const q=document.getElementById("searchInput").value.toLowerCase();
 const area=document.getElementById("areaFilter").value;
 const list=shops.filter(s=>(area==="all"||s.area===area)&&
 (s.name.toLowerCase().includes(q)||s.area.toLowerCase().includes(q)||s.items.some(x=>x.toLowerCase().includes(q))));
 render(list);
 status.textContent=list.length?`${list.length} nearby shop(s) found.`:"No matching shop found.";
}
document.getElementById("searchBtn").onclick=filter;
document.getElementById("searchInput").addEventListener("keydown",e=>{if(e.key==="Enter")filter()});
document.getElementById("areaFilter").onchange=filter;
document.getElementById("nearBtn").onclick=()=>{render(shops.slice(0,3));status.textContent="Showing demo shops nearest to your current area.";};

const modal=document.getElementById("modal");
document.getElementById("shopBtn").onclick=()=>modal.classList.remove("hidden");
document.getElementById("closeModal").onclick=()=>modal.classList.add("hidden");
document.getElementById("saveShop").onclick=()=>{
 const name=document.getElementById("newShop").value.trim();
 const area=document.getElementById("newArea").value.trim()||"Local area";
 if(!name){document.getElementById("formMsg").textContent="Please enter a shop name.";return;}
 shops.push({name,area,distance:"New",rating:"New",items:["Grocery","Daily needs"],phone:"Not provided"});
 render(shops);modal.classList.add("hidden");document.getElementById("formMsg").textContent="";
};
render();
