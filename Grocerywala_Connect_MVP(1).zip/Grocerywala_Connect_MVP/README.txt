Grocerywala Connect - 6-hour hackathon MVP

HOW TO RUN:
1. Extract the ZIP.
2. Open the folder in VS Code.
3. Open index.html.
4. Double-click index.html OR use VS Code Live Server if installed.

This version is a frontend MVP and needs no Python packages or internet.
Demo features:
- Search shops/products/areas
- Area filter
- Nearby shops demo
- Shop details
- Register a new shop (demo)
- Responsive design

Future features:
- Real GPS + maps
- Real shop-owner login
- Product inventory
- Online orders
- Database/backend
- UPI/payment integration
